# Proyecto Final — Análisis de Sentimiento de Tweets
## Curso: Automatización con n8n y LLMs · CoderHouse

---

## Descripción del Proyecto

Workflow automatizado en n8n que monitorea una hoja de Google Sheets con tweets, clasifica su sentimiento usando Google Gemini AI, y envía notificaciones por email cuando se detectan comentarios negativos.

**Stack:** n8n (localhost) · Google Gemini 2.0 Flash · Google Sheets · Gmail

---

## Arquitectura del Workflow

```
[Google Sheets Trigger]
    Nueva fila detectada
         ↓
[LLM 1 - Gemini Clasificador]
    Output: POSITIVO | NEGATIVO
         ↓
[Extraer Sentimiento (Set)]
    Normaliza: .trim().toUpperCase()
         ↓
[IF: ¿sentiment == NEGATIVO?]
    /              \
  SÍ               NO
   ↓                ↓
[LLM 2 -        [Log Positivo]
 Gemini          Sin acción
 Analizador]
   ↓
[Parsear JSON]
 try/catch fallback
   ↓
[Gmail - Email HTML]
 Con resumen y razones
```

---

## Requisitos Previos

- n8n instalado localmente (versión 2.8+)
- Cuenta de Google con Google Sheets y Gmail
- API Key de Google Gemini (aistudio.google.com)

---

## Cómo Importar y Ejecutar

**1. Importar el workflow:**
- En n8n: click "+" → workflow nuevo → "..." → "Import from File"
- Seleccionar `workflow.json`

**2. Configurar credenciales:**

*Google Sheets OAuth2:*
- Google Cloud Console → APIs → Google Sheets API → Habilitar
- Credenciales → OAuth2 → Aplicación Web
- Redirect URI: `http://localhost:5678/rest/oauth2-credential/callback`
- En n8n: Settings → Credentials → Google Sheets OAuth2 API

*Google Gemini:*
- Ir a aistudio.google.com → Get API Key → Create API Key
- En n8n: Settings → Credentials → Google Gemini(PaLM) API

*Gmail OAuth2:*
- Google Cloud Console → Gmail API → Habilitar
- Mismas credenciales OAuth2 de Google Sheets
- En n8n: Settings → Credentials → Gmail OAuth2

**3. Configurar la hoja de Google Sheets:**
- Crear hoja con columnas: `tweet` | `row_number`
- Copiar el ID de la URL y pegarlo en el nodo Google Sheets Trigger

**4. Activar el workflow:**
- Click en "Publish" arriba a la derecha

---

## Tweets de Prueba

| tweet | row_number | Resultado esperado |
|-------|------------|-------------------|
| Llevé mi auto al servicio técnico y fue una experiencia pésima. 3 horas de espera y no arreglaron nada. Nunca más. | 1 | NEGATIVO → Email enviado |
| Excelente servicio, me atendieron rápido y resolvieron todo. Muy recomendado! | 2 | POSITIVO → Sin email |
| Pésima experiencia con el soporte técnico, nunca resuelven nada y te hacen perder el tiempo. | 3 | NEGATIVO → Email enviado |

---

## Estructura del ZIP

```
proyecto_final_coderhouse.zip
├── workflow.json          → Importable en n8n
├── prompts.txt            → Prompts de cada nodo LLM
├── README.md              → Este archivo
├── documentacion.pdf      → Documentación técnica completa
└── evidencias/
    ├── workflow_editor.png     → Captura del workflow en n8n
    ├── email_negativo_1.png    → Email tweet negativo fila #1
    ├── email_negativo_2.png    → Email tweet negativo fila #2
    ├── email_negativo_3.png    → Email tweet negativo fila #3
    └── google_sheet.png        → Hoja de cálculo con tweets
```

---

## Seguridad

- No se incluyen credenciales reales en ningún archivo
- Las credenciales se configuran exclusivamente en el gestor de n8n
- El workflow.json contiene solo placeholders (YOUR_CREDENTIAL_ID)

---

## Manejo de Errores

| Escenario | Manejo |
|-----------|--------|
| LLM devuelve texto con puntuación | `.trim().toUpperCase()` normaliza |
| LLM 2 devuelve JSON con markdown | Code node limpia bloques ```json``` |
| JSON inválido del LLM 2 | try/catch devuelve error sin romper flujo |
| Rate limit de Gemini API | Error visible en Executions de n8n |
