# Pre-entrega — Alerta de Horario por Ciudad
## Curso: Automatización con n8n · CoderHouse

---

## Caso elegido
Monitoreo de horario: cuando se agrega una fila a Google Sheets con una ciudad, el workflow consulta la hora actual en Buenos Aires via API pública (timeapi.io). Si es de tarde/noche, envía alerta por email. Si es de mañana, registra el resultado sin notificar.

---

## ¿Qué dispara el workflow?
**Trigger:** Google Sheets → "Row Added". Cada vez que se agrega una fila nueva, el workflow se ejecuta automáticamente sin intervención manual.

---

## Descripción de cada nodo

| Nodo | Descripción |
|------|-------------|
| **Google Sheets Trigger** | Detecta filas nuevas en la hoja. Columna A = `ciudad`. Se activa automáticamente. |
| **Obtener Hora Actual (API)** | Llama a `timeapi.io` (API pública, sin token). Devuelve hora actual de Buenos Aires. |
| **Extraer y Normalizar Datos** | Extrae y normaliza: hora local, datetime completo, ciudad y día de la semana. |
| **Es PM?** | IF: evalúa si `hora_completa` contiene "T2" (horas 20-23hs). TRUE = email. FALSE = log. |
| **Gmail - Alerta PM** | Envía email HTML con ciudad, hora y aviso de tarde/noche. |
| **Log AM - Sin Alerta** | Registra resultado con timestamp sin enviar notificación. |

---

## ¿Qué evalúa el condicional y por qué?
El nodo IF evalúa si el campo `hora_completa` (formato ISO: 2026-03-09T21:18:00) contiene "T2". Esto detecta horas entre 20:00 y 23:59 de forma simple sin conversiones de tipo.

---

## Cómo configurar la notificación (Gmail)
1. Google Cloud Console → habilitar Gmail API
2. Crear credenciales OAuth2 → Client ID + Secret
3. En n8n: Settings → Credentials → Add → Gmail OAuth2
4. Pegar Client ID y Secret → Sign in with Google → autorizar
5. En el nodo Gmail → campo "To": ingresar email destinatario

---

## API utilizada
- **TimeAPI:** `https://timeapi.io/api/time/current/zone?timeZone=America/Argentina/Buenos_Aires`
- Sin autenticación · Gratuita · Documentación: timeapi.io

---

## Buenas prácticas aplicadas
- Credenciales almacenadas en gestor de n8n, nunca en archivos exportados
- Cada fila genera una ejecución independiente (idempotencia)
- Rama AM registra resultado con timestamp para auditoría
- API pública sin token requerido

---

## Cómo importar y ejecutar
1. En n8n: click "+" → workflow nuevo → "..." → "Import from File"
2. Seleccionar `workflow_preentrega.json`
3. Configurar credenciales: Google Sheets OAuth2 y Gmail OAuth2
4. En Google Sheets Trigger: reemplazar ID de la hoja
5. En Gmail: poner email destinatario real
6. Click "Publish" → agregar fila en la hoja para probar

---

## Estructura del ZIP
```
pre_entrega_coderhouse.zip
├── workflow_preentrega.json
├── README_preentrega.md
└── evidencias/
    ├── email_recibido.png
    └── executions_n8n.png
```
